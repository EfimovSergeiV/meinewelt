/**
 * Copyright 2018 Google Inc. All Rights Reserved.
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *     http://www.apache.org/licenses/LICENSE-2.0
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

// If the loader is already loaded, just stop.
if (!self.define) {
  let registry = {};

  // Used for `eval` and `importScripts` where we can't get script URL by other means.
  // In both cases, it's safe to use a global var because those functions are synchronous.
  let nextDefineUri;

  const singleRequire = (uri, parentUri) => {
    uri = new URL(uri + ".js", parentUri).href;
    return registry[uri] || (
      
        new Promise(resolve => {
          if ("document" in self) {
            const script = document.createElement("script");
            script.src = uri;
            script.onload = resolve;
            document.head.appendChild(script);
          } else {
            nextDefineUri = uri;
            importScripts(uri);
            resolve();
          }
        })
      
      .then(() => {
        let promise = registry[uri];
        if (!promise) {
          throw new Error(`Module ${uri} didn’t register its module`);
        }
        return promise;
      })
    );
  };

  self.define = (depsNames, factory) => {
    const uri = nextDefineUri || ("document" in self ? document.currentScript.src : "") || location.href;
    if (registry[uri]) {
      // Module is already loading or loaded.
      return;
    }
    let exports = {};
    const require = depUri => singleRequire(depUri, uri);
    const specialDeps = {
      module: { uri },
      exports,
      require
    };
    registry[uri] = Promise.all(depsNames.map(
      depName => specialDeps[depName] || require(depName)
    )).then(deps => {
      factory(...deps);
      return exports;
    });
  };
}
define(['./workbox-86c9b217'], (function (workbox) { 'use strict';

  self.skipWaiting();
  workbox.clientsClaim();

  /**
   * The precacheAndRoute() method efficiently caches and responds to
   * requests for URLs in the manifest.
   * See https://goo.gl/S9QRab
   */
  workbox.precacheAndRoute([{
    "url": "_nuxt/B9K5rw8f.js",
    "revision": null
  }, {
    "url": "_nuxt/bk-orsfE.js",
    "revision": null
  }, {
    "url": "_nuxt/C_9oJ4u_.js",
    "revision": null
  }, {
    "url": "_nuxt/CAeLvA1-.js",
    "revision": null
  }, {
    "url": "_nuxt/CN4gCD2a.js",
    "revision": null
  }, {
    "url": "_nuxt/D6NPvZ4h.js",
    "revision": null
  }, {
    "url": "_nuxt/DpBjjeKL.js",
    "revision": null
  }, {
    "url": "_nuxt/error-404.gSG-APzC.css",
    "revision": null
  }, {
    "url": "_nuxt/error-500.DxD0xVYQ.css",
    "revision": null
  }, {
    "url": "favicon.ico",
    "revision": "5c1028350a39fb9e5a9bfbe280326e28"
  }, {
    "url": "_nuxt/builds/latest.json",
    "revision": "dcb6975e24ae80cabaa4a8f1cac9e387"
  }, {
    "url": "_nuxt/builds/meta/6d1030a7-b306-4492-9487-0d2c85c96a4b.json",
    "revision": null
  }, {
    "url": "manifest.webmanifest",
    "revision": "2cec950910b6b04399eafd7f3a55a78f"
  }], {});
  workbox.cleanupOutdatedCaches();
  workbox.registerRoute(new workbox.NavigationRoute(workbox.createHandlerBoundToURL("/")));

}));
